package com.example.gestordenotas;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private DatabaseReference databaseReference;

    private EditText etAsignatura, etNota1, etNota2, etNota3, etNota4;
    private EditText etPond1, etPond2, etPond3, etPond4;
    private Spinner spinnerAsignaturas;
    private TextView tvResultado;

    private ArrayAdapter<String> spinnerAdapter;
    private ArrayList<String> listaAsignaturas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseReference = FirebaseDatabase.getInstance().getReference("asignaturas");

        etAsignatura = findViewById(R.id.etAsignatura);
        etNota1 = findViewById(R.id.etNota1);
        etNota2 = findViewById(R.id.etNota2);
        etNota3 = findViewById(R.id.etNota3);
        etNota4 = findViewById(R.id.etNota4);

        etPond1 = findViewById(R.id.etPond1);
        etPond2 = findViewById(R.id.etPond2);
        etPond3 = findViewById(R.id.etPond3);
        etPond4 = findViewById(R.id.etPond4);

        spinnerAsignaturas = findViewById(R.id.spinnerAsignaturas);
        tvResultado = findViewById(R.id.tvResultado);

        Button btnAgregar = findViewById(R.id.btnAgregar);
        Button btnBuscar = findViewById(R.id.btnBuscar);

        listaAsignaturas = new ArrayList<>();
        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, listaAsignaturas);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerAsignaturas.setAdapter(spinnerAdapter);

        btnAgregar.setOnClickListener(v -> agregarAsignatura());
        btnBuscar.setOnClickListener(v -> buscarAsignatura());

        cargarAsignaturas();
    }

    private void agregarAsignatura() {
        String asignatura = etAsignatura.getText().toString().trim();
        String nota1Str = etNota1.getText().toString().trim();
        String nota2Str = etNota2.getText().toString().trim();
        String nota3Str = etNota3.getText().toString().trim();
        String nota4Str = etNota4.getText().toString().trim();

        String pond1Str = etPond1.getText().toString().trim();
        String pond2Str = etPond2.getText().toString().trim();
        String pond3Str = etPond3.getText().toString().trim();
        String pond4Str = etPond4.getText().toString().trim();

        if (asignatura.isEmpty() || nota1Str.isEmpty() || nota2Str.isEmpty() || nota3Str.isEmpty() || nota4Str.isEmpty()
                || pond1Str.isEmpty() || pond2Str.isEmpty() || pond3Str.isEmpty() || pond4Str.isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double nota1 = Double.parseDouble(nota1Str);
            double nota2 = Double.parseDouble(nota2Str);
            double nota3 = Double.parseDouble(nota3Str);
            double nota4 = Double.parseDouble(nota4Str);

            double pond1 = Double.parseDouble(pond1Str) / 100;
            double pond2 = Double.parseDouble(pond2Str) / 100;
            double pond3 = Double.parseDouble(pond3Str) / 100;
            double pond4 = Double.parseDouble(pond4Str) / 100;

            if (pond1 + pond2 + pond3 + pond4 != 1.0) {
                Toast.makeText(this, "Las ponderaciones deben sumar 100%", Toast.LENGTH_SHORT).show();
                return;
            }

            double promedio = (nota1 * pond1) + (nota2 * pond2) + (nota3 * pond3) + (nota4 * pond4);

            Map<String, Object> datos = new HashMap<>();
            datos.put("nota1", nota1);
            datos.put("nota2", nota2);
            datos.put("nota3", nota3);
            datos.put("nota4", nota4);
            datos.put("pond1", pond1);
            datos.put("pond2", pond2);
            datos.put("pond3", pond3);
            datos.put("pond4", pond4);
            datos.put("promedio", promedio);

            databaseReference.child(asignatura).setValue(datos)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Asignatura agregada correctamente", Toast.LENGTH_SHORT).show();
                        limpiarCampos();
                        cargarAsignaturas();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Error al agregar asignatura", Toast.LENGTH_SHORT).show());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Por favor, ingresa valores numéricos válidos", Toast.LENGTH_SHORT).show();
        }
    }

    private void buscarAsignatura() {
        String asignaturaSeleccionada = spinnerAsignaturas.getSelectedItem().toString();

        databaseReference.child(asignaturaSeleccionada).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                Object value = task.getResult().getValue();
                if (value instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> datos = (Map<String, Object>) value;

                    if (datos.containsKey("promedio") && datos.get("promedio") != null) {
                        Object promedioObj = datos.get("promedio");
                        if (promedioObj instanceof Number) {
                            double promedio = ((Number) promedioObj).doubleValue();
                            tvResultado.setText(getString(R.string.promedio_asignatura, asignaturaSeleccionada, promedio));
                        } else {
                            tvResultado.setText(R.string.error_datos);
                        }
                    } else {
                        tvResultado.setText(R.string.error_datos);
                    }
                } else {
                    tvResultado.setText(R.string.error_datos);
                }
            } else {
                tvResultado.setText(R.string.asignatura_no_existe);
            }
        });
    }



    private void cargarAsignaturas() {
        databaseReference.get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                listaAsignaturas.clear();
                for (DataSnapshot snapshot : task.getResult().getChildren()) {
                    listaAsignaturas.add(snapshot.getKey());
                }
                spinnerAdapter.notifyDataSetChanged();
            }
        });
    }

    private void limpiarCampos() {
        etAsignatura.setText("");
        etNota1.setText("");
        etNota2.setText("");
        etNota3.setText("");
        etNota4.setText("");
        etPond1.setText("");
        etPond2.setText("");
        etPond3.setText("");
        etPond4.setText("");
    }
}
